import React, {Component} from 'react';
import {
  View,
  Text,
  Image,
  TouchableOpacity,
  StyleSheet,
  ImageBackground,
  ScrollView,
} from 'react-native';
import FavoriteButton from '../components/FavoriteButton';

class Home extends Component {
  constructor(props) {
    super(props);

    this.state = {};
  }

  render() {
    return (
      <ScrollView style={{flex: 1}}>
        <View style={styles.header}>
          <View style={styles.firstSection}>
            <TouchableOpacity>
              <Image
                source={require('../assets/icons/IconMenuDrop.png')}
                style={{width: 30, height: 30}}
              />
            </TouchableOpacity>
            <TouchableOpacity>
              <Image
                source={require('../assets/icons/IconNotifikasi.png')}
                style={{width: 25, height: 25}}
              />
            </TouchableOpacity>
          </View>
          <View style={styles.secondSection}>
            <Text style={{fontSize: 20, fontWeight: '500', color: '#F5F5F5'}}>
              Top Of The Week
            </Text>
            <TouchableOpacity>
              <Text style={{fontSize: 15, color: '#C3C3C3'}}>View All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.thirdSection}>
            <View>
              <ImageBackground
                source={require('../assets/images/background.jpg')}
                style={styles.imagebackground}>
                <Image
                  source={require('../assets/images/lumpu.jpg')}
                  style={{width: 100, height: 160}}
                />
              </ImageBackground>
            </View>
            <View>
              <View
                style={{
                  flexDirection: 'row',
                  justifyContent: 'space-between',
                  width: 180,
                }}>
                <Text
                  style={{fontSize: 20, fontWeight: '500', color: '#F5F5F5'}}>
                  Lumpu
                </Text>
                <View style={styles.ratings}>
                  <Image
                    source={require('../assets/icons/IconStar.png')}
                    style={{width: 18, height: 18, marginRight: 3}}
                  />
                  <Text style={{fontSize: 18, color: '#212121'}}>4.5</Text>
                </View>
              </View>
              <View style={{marginTop: 10}}>
                <Text style={{fontSize: 16, color: '#F5F5F5'}}>
                  By Tere Liye
                </Text>
              </View>
              {/* category */}
              <View style={{flexDirection: 'row', marginTop: 16}}>
                <Text
                  style={[styles.minicategory, {backgroundColor: '#4085B4'}]}>
                  Romance
                </Text>
                <Text
                  style={[styles.minicategory, {backgroundColor: '#ad8cd3'}]}>
                  Sci-fi
                </Text>
                <Text
                  style={[styles.minicategory, {backgroundColor: '#886ed4'}]}>
                  Family
                </Text>
              </View>
              <View style={{marginTop: 16}}>
                <Text style={{fontSize: 16, color: '#F5F5F5'}}>
                  Reading By 15 Friends
                </Text>
              </View>
              <View style={{marginTop: 16}}>
                <TouchableOpacity>
                  <Text style={styles.primerbutton}>See Details</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        </View>
        {/* Category */}
        <View style={styles.categorySection}>
          <View style={[styles.secondSection, {marginTop: 0}]}>
            <Text style={{fontSize: 20, fontWeight: 'bold', color: '#212121'}}>
              Category
            </Text>
            <TouchableOpacity>
              <Text style={{fontSize: 15, color: '#8B8D92'}}>View All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.categorywrap}>
            <TouchableOpacity
              style={{alignItems: 'center'}}
              onPress={() =>
                this.props.navigation.navigate('List', {category: 'Fantasy'})
              }>
              <View style={styles.category}>
                <Image
                  source={require('../assets/icons/fantasy.png')}
                  style={styles.categoryicons}
                />
              </View>

              <Text>Fantasy</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{alignItems: 'center'}}
              onPress={() =>
                this.props.navigation.navigate('List', {category: 'Romance'})
              }>
              <View style={styles.category}>
                <Image
                  source={require('../assets/icons/romance.png')}
                  style={styles.categoryicons}
                />
              </View>
              <Text>Romance</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{alignItems: 'center'}}
              onPress={() =>
                this.props.navigation.navigate('List', {category: 'Mystery'})
              }>
              <View style={styles.category}>
                <Image
                  source={require('../assets/icons/mistery.png')}
                  style={styles.categoryicons}
                />
              </View>

              <Text>Mystery</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={{alignItems: 'center'}}
              onPress={() =>
                this.props.navigation.navigate('List', {category: 'Horror'})
              }>
              <View style={styles.category}>
                <Image
                  source={require('../assets/icons/horror.png')}
                  style={styles.categoryicons}
                />
              </View>
              <Text>Horror</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.secondSection}>
            <Text style={{fontSize: 20, fontWeight: 'bold', color: '#212121'}}>
              New Arrivals
            </Text>
            <TouchableOpacity>
              <Text style={{fontSize: 15, color: '#8B8D92'}}>View All</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.arrivalswrap}>
            <View style={styles.container}>
              <TouchableOpacity style={styles.imageContainer}>
                <ImageBackground
                  source={require('../assets/images/background.jpg')}
                  style={styles.imagebackgroundshadow}>
                  <Image
                    source={require('../assets/images/dilan.jpg')}
                    style={{width: 130, height: 180}}
                  />
                </ImageBackground>
              </TouchableOpacity>
              <FavoriteButton gaya={{top: 10, right: 15}} />
            </View>
            <TouchableOpacity style={{alignItems: 'center'}}>
              <ImageBackground
                source={require('../assets/images/background.jpg')}
                style={styles.imagebackgroundshadow}>
                <Image
                  source={require('../assets/images/bumi-manusia.jpg')}
                  style={{width: 130, height: 180}}
                />
              </ImageBackground>
            </TouchableOpacity>
            <FavoriteButton gaya={{top: 10, right: 15}}/>
          </View>
        </View>
      </ScrollView>
    );
  }
}
const styles = StyleSheet.create({
  header: {
    height: 440,
    padding: 20,
    // width: FullWindowOverlay,
    alignItems: 'center',
    backgroundColor: '#043657',
  },

  firstSection: {
    marginTop: 30,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // backgroundColor: '#4085B4',
    width: 350,
  },

  secondSection: {
    marginTop: 20,
    flexDirection: 'row',
    justifyContent: 'space-between',
    // backgroundColor: '#0E5381',
    width: 350,
    alignItems: 'center',
  },
  thirdSection: {
    marginTop: 30,
    padding: 20,
    flexDirection: 'row',
    backgroundColor: '#0E5381',
    width: 350,
    borderRadius: 10,
    overflow: 'hidden',
  },
  categorySection: {
    height: 440,
    padding: 30,
    // width: FullWindowOverlay,
    // alignItems: 'center',
    backgroundColor: '#f5f5f5',
    marginBottom:30
  },
  imagebackground: {
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 7,
    overflow: 'hidden',
    marginRight: 7,
  },
  ratings: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F5F5F5',
    paddingHorizontal: 10,
    borderRadius: 10,
    overflow: 'hidden',
  },
  minicategory: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 5,
    overflow: 'hidden',
    fontSize: 12,
    marginRight: 5,
    color: '#F5F5F5',
  },
  primerbutton: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 5,
    overflow: 'hidden',
    fontSize: 16,
    color: '#F5F5F5',
    backgroundColor: '#F08F1D',
    alignSelf: 'flex-end',
  },
  categorywrap: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'space-between',
  },
  category: {
    borderRadius: 50,
    overflow: 'hidden',
    backgroundColor: '#4085B4',
    padding: 10,
  },
  categoryicons: {
    width: 55,
    height: 55,
  },
  arrivalswrap: {
    flexDirection: 'row',
    marginTop: 20,
    justifyContent: 'space-between',
    paddingBottom:30
  },
  imagebackgroundshadow: {
    padding: 14,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 7,
    overflow: 'hidden',
    marginRight: 7,
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowOpacity: 0.3,
    shadowRadius: 4.65,
    elevation: 8,
  },
});

export default Home;
